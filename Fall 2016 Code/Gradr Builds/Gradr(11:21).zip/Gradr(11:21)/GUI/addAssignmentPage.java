package GUI;
import Logic.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.List;
import java.awt.event.*;

public class addAssignmentPage extends JFrame{


    public addAssignmentPage(String className){
        setTitle("New Assignment");
        String prompt = new String("Assignment");
        JLabel promptLabel = new JLabel();
        Font promptFont= new Font("Stencil", Font.PLAIN, 20);
        Font labelFont= new Font("Stencil", Font.PLAIN, 20);
        promptLabel.setText(prompt);
        promptLabel.setFont(promptFont);
        
        JLabel nameLabel = new JLabel("Name:");
        JLabel weightLabel = new JLabel("Weight:");
        JLabel totalPointsLabel= new JLabel("Points Possible:");

        nameLabel.setFont(labelFont);
        weightLabel.setFont(labelFont);
        totalPointsLabel.setFont(labelFont);

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        JTextField nameField = new JTextField();
        JTextField weightField = new JTextField(3);
        JTextField totalPointsField = new JTextField(3);

        setResizable(false);
        setVisible(true);
        setSize(600,200);
        GridLayout layout = new GridLayout(0,3);
        setLayout(layout);
        
        add(Box.createRigidArea(new Dimension(0,0)));
        add(promptLabel);
        add(Box.createRigidArea(new Dimension(0,0)));
        
        add(nameLabel);
        add(nameField);
        add(saveButton);
        

        add(weightLabel);
        add(weightField);
        add(cancelButton);
        
        add(totalPointsLabel);
        add(totalPointsField);
        add(Box.createRigidArea(new Dimension(0,0)));
        

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    String name = nameField.getText();
                    int weight = Integer.parseInt(weightField.getText());
                    int totalPoints = Integer.parseInt(totalPointsField.getText());
                    FileIO io = new FileIO();
                    io.addAssignment(className,name,weight,totalPoints);
                    io.setDefaultValuesForGradesWhenAddingANewAssignment(className);
                    
                    dispose();
                }
                catch(Exception x){
                    JOptionPane.showMessageDialog(null,"ERROR: Incorrect entry for weight or total points!\nIt must be an Interger.");
                }
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
