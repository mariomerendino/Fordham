package GUI;
import Logic.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.List;
import java.awt.event.*;

public class addStudentPage extends JFrame{
   
    public static teacher currentTeacher;

    public JTextField firstNameField = new JTextField();
    public JTextField lastNameField = new JTextField();
    public JTextField ageField = new JTextField();
    public JTextField idField = new JTextField();
    public JComboBox dropDown = createDropDown();

    public static void main(String [] args){
        addStudentPage page = new addStudentPage();
    }
    public addStudentPage(){
        String prompt = new String("New Student");
        JLabel promptLabel = new JLabel();
        Font promptFont= new Font("Stencil", Font.PLAIN, 32);
        Font labelFont= new Font("Stencil", Font.PLAIN, 20);
        promptLabel.setText(prompt);
        promptLabel.setFont(promptFont);
        
        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel classLabel = new JLabel("Class:");
        JLabel ageLabel = new JLabel("Age:");
        JLabel idLabel = new JLabel("Student Id:");

        firstNameLabel.setFont(labelFont);
        lastNameLabel.setFont(labelFont);
        classLabel.setFont(labelFont);
        ageLabel.setFont(labelFont);
        idLabel.setFont(labelFont);

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField ageField = new JTextField(3);
        JTextField idField = new JTextField();

        setResizable(false);
        setVisible(true);
        setSize(1000,250);
        GridLayout layout = new GridLayout(0,3);
        setLayout(layout);
        
        add(Box.createRigidArea(new Dimension(0,0)));
        add(promptLabel);
        add(Box.createRigidArea(new Dimension(0,0)));
        
        add(firstNameLabel);
        add(firstNameField);
        add(saveButton);
        
        add(lastNameLabel);
        add(lastNameField);
        add(cancelButton);

        add(classLabel);
        add(dropDown);
        add(Box.createRigidArea(new Dimension(0,0)));
        

        add(ageLabel);
        add(ageField);
        add(Box.createRigidArea(new Dimension(0,0)));
        
        add(idLabel);
        add(idField);
        add(Box.createRigidArea(new Dimension(0,0)));

        saveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FileIO addStudent = new FileIO();
                    String className = (String)dropDown.getSelectedItem();
                    String firstName = firstNameField.getText();
                    String lastName = lastNameField.getText();
                    int age =  Integer.parseInt(ageField.getText());
                    String id = idField.getText();
                    student newStudent = new student();
                    newStudent.setStudentInfo(firstName, lastName, age, id);
                    addStudent.appendStudent(newStudent, className);
                    dispose();
                }
            });
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    public JComboBox createDropDown(){
        FileIO io = new FileIO();
        List<String> classList = new ArrayList<String>();
        classList = io.readClassList(currentTeacher.username);
        String[] classArray = new String[classList.size()];
        for(int i=0; i < classList.size(); i++){
            classArray[i] = classList.get(i);
        }
        JComboBox box = new JComboBox(classArray);
        return box;
    }
}