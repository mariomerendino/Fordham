import java.util.*;
import javax.swing.*;
import java.awt.*;
import GUI.*;
import Logic.*;
import java.io.*;


public class Start {
    public static void main(String [] args){
        FontLoader fonts = new FontLoader();
        Login go = new Login();
    }
}
