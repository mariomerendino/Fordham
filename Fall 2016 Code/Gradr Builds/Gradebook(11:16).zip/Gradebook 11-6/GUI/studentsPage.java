package GUI;
import Logic.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;
import java.awt.Color;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

 public class studentsPage extends JPanel{
    public static teacher currentTeacher;
    public JComboBox classDropDown = new JComboBox();

    public JLabel title = new JLabel();
    public Font titleFont= new Font("Stencil", Font.PLAIN, 40);
    public BorderLayout studentsPageLayout = new BorderLayout();

    public static String classroom = new String();
    public studentsPage(){
        classDropDown = createDropDown();
        JPanel topBar = new JPanel();

        FlowLayout barLayout = new FlowLayout();
        topBar.setLayout(barLayout);

        setLayout(studentsPageLayout);

        title.setText("Master Students List");
        title.setFont(titleFont);
        title.setVisible(true);
        topBar.add(title);
        
        topBar.add(classDropDown);
        JButton update = new JButton("Update");
        topBar.add(update);
        add(topBar, studentsPageLayout.NORTH);
        update.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                update((String)classDropDown.getSelectedItem());
            }
        });
        
        /*JPanel bottomBar = new JPanel();
        GridLayout bottomBarLayout = new GridLayout(0,3);
        bottomBar.setLayout(bottomBarLayout);
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        bottomBar.add(Box.createHorizontalStrut(10));
        bottomBar.add(saveButton);
        bottomBar.add(cancelButton);*/
        
        add(new DataFileTable2(), studentsPageLayout.CENTER);
        //add(bottomBar, studentsPageLayout.SOUTH);
    }
    public void update(String classroom){
        title.setText(classroom);
        if (classroom == "Master Students List"){
            swapCenter(new DataFileTable2());
        }
        else{
            swapCenter(new DataFileTable2(classroom));
        }
        
    }
    public void swapCenter(JPanel replacementPanel){
        if (studentsPageLayout.getLayoutComponent(studentsPageLayout.CENTER) != null) {
            remove(studentsPageLayout.getLayoutComponent(studentsPageLayout.CENTER));
        }
            
        add(replacementPanel, studentsPageLayout.CENTER);
        validate();
        repaint();
    }
    public JComboBox createDropDown(){
        FileIO io = new FileIO();
        List<String> classList = new ArrayList<String>();
        classList = io.readClassList(currentTeacher.username);
        String[] classArray = new String[classList.size()+1];
        classArray[0] = "Master Students List";
        for(int i=1; i < classList.size()+1; i++){
            classArray[i] = classList.get(i-1);
        }
        JComboBox box = new JComboBox(classArray);
        return box;
     }
 }