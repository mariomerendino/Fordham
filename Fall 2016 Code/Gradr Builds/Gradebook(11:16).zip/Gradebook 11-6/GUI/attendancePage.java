package GUI;
import Logic.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;
import java.awt.Color;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class attendancePage extends JFrame {
	
    public static teacher currentTeacher;
	String username = currentTeacher.username;
    int attendance = 0;

    public attendancePage(String className){
        GridLayout pageLayout = new GridLayout(0,3);
        setLayout(pageLayout);
        JLabel name = new JLabel("FirstName");
        JLabel lastName = new JLabel("LastName");
        JTextField attendanceBox = new JTextField(Integer.toString(attendance));
    
        setVisible(true);
        setSize(500,1000);
        add(name);
        add(lastName);
        add(attendanceBox);


   
        
    }

    public void save(){

    }
    public static void main( String [] args ){
        attendancePage page = new attendancePage("t");
    }
    
}
    