package GUI;
import Logic.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

public class login extends JFrame{
    
    //Declares all text fields and buttons
    javax.swing.JButton loginButton = new JButton();
    javax.swing.JButton registerButton = new JButton();
    javax.swing.JPasswordField passwordField = new JPasswordField(8);
    javax.swing.JLabel passwordLabel = new JLabel();
    javax.swing.JLabel usernameLabel = new JLabel();
    javax.swing.JTextField usernameField = new JTextField(8);
    public static teacher currentTeacher = new teacher();
    

    public login(){
        setTitle("Gradr Login");
        //Creates a Listener for the login button
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        //creates a Listener for the registerButton
        registerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerButtonActionPerformed(evt);
            }
        });
        //sets size
        setSize(250,200);
        //Sets layout to be a flow layout.
        BorderLayout bLayout = new BorderLayout();

        JPanel centerPanel = new JPanel();
        GridLayout gLayout = new GridLayout(2,2);
        
        setLayout(bLayout);
        //Sets values for all objects in the GUI
        usernameLabel.setText("Username: ");
        passwordLabel.setText("Password: ");
        usernameField.setText("");
        passwordField.setText("");
        loginButton.setText("Enter");
        registerButton.setText("Register");
        //Adds all objects to the Frame
        centerPanel.add(usernameLabel);
        centerPanel.add(usernameField);
        centerPanel.add(passwordLabel);
        centerPanel.add(passwordField);
        centerPanel.add(loginButton);
        centerPanel.add(registerButton);

        add(createFooter(), BorderLayout.SOUTH);
        add(centerPanel, BorderLayout.CENTER);
        //Sets its visibility
        setVisible(true);
        
    }
    /*public static void main ( String [] args ){
        login t = new login();
    }*/
    private void registerButtonActionPerformed(java.awt.event.ActionEvent evt) {
        FileIO io = new FileIO();
        io.teacherRegistration();
        
    }
    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {
        FileIO io = new FileIO();
        String pass = new String(passwordField.getPassword());
        if(io.login(usernameField.getText(), pass)){
            teacher t1 = new teacher();
            t1 = io.readTeacher(usernameField.getText());
            currentTeacher = t1;
            gradebook g = new gradebook(t1);
            dashboard frame = new dashboard();
            dispose();
        }
        else{
            JOptionPane.showMessageDialog(null,"ERROR: Incorrect username or password ");
        }
    }
     public JApplet createFooter(){
        JApplet footer = new JApplet();
        footer.getContentPane().setBackground(new Color(255,255,255));
        ImageIcon gradrlogo = new ImageIcon(new ImageIcon(System.getProperty("user.dir") +"/GUI/gradrlogo.png").getImage().getScaledInstance(200, 50, Image.SCALE_SMOOTH));
        JLabel logoLabel = new JLabel(gradrlogo);
        footer.add(logoLabel);
        return footer;
    }
}