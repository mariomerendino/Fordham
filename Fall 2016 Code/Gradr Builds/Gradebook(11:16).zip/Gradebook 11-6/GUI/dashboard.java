package GUI;
import Logic.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;
import java.awt.Color;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class dashboard extends JFrame{
        public static teacher currentTeacher;
        //Constructor for the dashboard

        BorderLayout bLayout = new BorderLayout(5,10); //verticalspace, horizontalspace 
        
        public dashboard(){
            setTitle("Gradr");
            setLayout(bLayout);
            //Sets the size of the the entire dashboard frame. 
            setExtendedState(JFrame.MAXIMIZED_BOTH); 
            setVisible(true);
            //adds a navigation to the top of the page. 
            add(createNavigationBar(), bLayout.NORTH);
            add(homePage(), bLayout.CENTER);
            //
            add(createFooter(), bLayout.SOUTH);
        }
        //Creates a Java Applet for the navigation bar at the top. 
        public JApplet createNavigationBar(){
            
            //Creates JApplet(Container) to eventually be returned
            JApplet navbar = new JApplet();
            navbar.getContentPane().setBackground(new Color(64, 63, 62));
            //gets Screen Size, used later...
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Double widthDouble = screenSize.getWidth()/1.7;
            int width = widthDouble.intValue(); 

            //Sets up the flowlayout for the nav bar. 
            FlowLayout fLayout = new FlowLayout(FlowLayout.LEFT,20,20);
            navbar.setLayout(fLayout);
        
            //Adds icon for the book.
            ImageIcon book = new ImageIcon(new ImageIcon(System.getProperty("user.dir") +"/GUI/book.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
            JLabel bookIcon = new JLabel(book);
            bookIcon.setSize(50,50);
            navbar.add(bookIcon);

            //Adds the exclamation point button icon. 
            ImageIcon exclam = new ImageIcon(new ImageIcon(System.getProperty("user.dir") +"/GUI/exclam.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
            JLabel exclamIcon = new JLabel(exclam);
            exclamIcon.setSize(40,40);

            //Adds the exclamation point button icon.
            ImageIcon plus = new ImageIcon(new ImageIcon(System.getProperty("user.dir") +"/GUI/plus.png").getImage().getScaledInstance(40, 40, Image.SCALE_DEFAULT));
            JLabel plusIcon = new JLabel(plus);
            plusIcon.setSize(40,40);
            
            //Creates Labels for home, students, and classes. 
            JLabel home = new JLabel( );
            JLabel students = new JLabel ();
            JLabel grades = new JLabel( );
            
            //Creates two new fonts one bold and the other not.
            Font notBold= new Font("SF UI Text", Font.PLAIN,20);
            Font fontBold = new Font("SF UI Text", Font.BOLD,21);
            
            //Sets the text and default bolding of each jlabel.
            home.setFont(fontBold);
            home.setText("Home");
            home.setForeground(new Color(255, 255, 255));
            students.setFont(notBold);
            students.setText("Students");
            students.setForeground(new Color(255, 255, 255));
	        grades.setFont(notBold);
	        grades.setText("Grades");
            grades.setForeground(new Color(255, 255, 255));
		
            
            //adds listeners for clicks on the Home, classes, studens, plus, and ExcalmationPoint
            home.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    home.setFont(fontBold);
                    //swaps the center so it displays the homepage. 
                    swapCenter(homePage());
                    students.setFont(notBold);
		            grades.setFont(notBold);
                }

            });
            students.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    home.setFont(notBold);
                    students.setFont(fontBold);
		            grades.setFont(notBold);
                    swapCenter(new studentsPage());
                }

            });

            grades.addMouseListener(new MouseAdapter( ) {
            @Override
            public void mouseClicked(MouseEvent e) {
                home.setFont(notBold);
                students.setFont(notBold);
                grades.setFont(fontBold);
                swapCenter(new assignmentsPage( ));
		    }
	        });

            exclamIcon.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JOptionPane.showMessageDialog(null, "ExcalmationPoint", "Button Clickeed", JOptionPane.PLAIN_MESSAGE);
                }

            });
            plusIcon.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    home.setFont(fontBold); 
                    swapCenter(homePage());
                    students.setFont(notBold);
		            grades.setFont(notBold);
                    addButtonPage test = new addButtonPage();
                    
                }

            });
            //adds the labels to the applet. 
            
            navbar.add(home);
            navbar.add(students);
	        navbar.add(grades);

            //creates a horizontalspace
            navbar.add(Box.createHorizontalStrut(width));

            //finally adds the last buttons to the applet. 
            navbar.add(plusIcon);
            navbar.add(exclamIcon);
            navbar.setVisible(true); 
            return navbar;
        }
        public JPanel homePage(){
            JPanel page = new JPanel();
            BorderLayout homePageLayout = new BorderLayout();
            page.setLayout(homePageLayout);

            JPanel titlePanel = new JPanel();
            FlowLayout titleLayout = new FlowLayout();
            titlePanel.setLayout(titleLayout);
            JLabel welcome = new JLabel();
            Font welcomeFont= new Font("Stencil", Font.PLAIN, 40);
            welcome.setText("Welcome, " + currentTeacher.firstName);
            welcome.setFont(welcomeFont);
            welcome.setVisible(true);
            titlePanel.add(welcome);

            page.add(titlePanel, homePageLayout.NORTH);

            JPanel centerPanel = new JPanel();
            GridLayout centerPanelLayout = new GridLayout(4,0);
            centerPanel.setLayout(centerPanelLayout);
            
            JLabel recentClassesLabel = new JLabel();
            Font otherLabelFont = new Font("Stencil", Font.PLAIN, 30);
            recentClassesLabel.setText("\t\tRecent Classes");
            recentClassesLabel.setFont(otherLabelFont);
            
            centerPanel.add(recentClassesLabel);

            JPanel buttonPannel = new JPanel();
            FlowLayout buttonPannelLayout = new FlowLayout();
            buttonPannel.setLayout(buttonPannelLayout);

            FileIO io = new FileIO();
            List<String> classList = new ArrayList<String>();
            classList = io.readClassList(currentTeacher.username);

            try{
                JButton class1 = new JButton(classList.get(0));
                buttonPannel.add(class1);
            }
            catch(Exception e){

            }
            try{
                JButton class2 = new JButton(classList.get(1));
                buttonPannel.add(class2);
            }
            catch(Exception e){

            }
            try{

                JButton class3 = new JButton(classList.get(2));
                buttonPannel.add(class3);
            }
            catch(Exception e){

            }
            try{
                JButton class4 = new JButton(classList.get(3));
                buttonPannel.add(class4);
            }
            catch(Exception e){

            }
            try{
                JButton class5 = new JButton(classList.get(4));
                buttonPannel.add(class5);
            }
            catch(Exception e){

            }
            centerPanel.add(buttonPannel);
            JLabel messagesLabel = new JLabel();
            messagesLabel.setText("\t\tMessages");
            messagesLabel.setFont(otherLabelFont);
            centerPanel.add(messagesLabel);
            
            JPanel notificationsPanel = new JPanel();
            FlowLayout notificationsPanelLayout = new FlowLayout();
            JLabel messages = new JLabel();
            Font notificationFont= new Font("Stencil", Font.PLAIN, 25);
            messages.setFont(notificationFont);
            messages.setText("No new messages...");
            notificationsPanel.add(messages);

            centerPanel.add(notificationsPanel);
            page.add(centerPanel, homePageLayout.CENTER);
            page.add(Box.createRigidArea(new Dimension(30,0)), homePageLayout.WEST);
            return page;
        }
        public void swapCenter(JPanel replacementPanel){
            if (bLayout.getLayoutComponent(bLayout.CENTER) != null) {
                remove(bLayout.getLayoutComponent(bLayout.CENTER));
            }
            
            add(replacementPanel, bLayout.CENTER);
            validate();
            repaint();
        }
        public JComboBox createDropDown(){
            FileIO io = new FileIO();
            List<String> classList = new ArrayList<String>();
            classList = io.readClassList(currentTeacher.username);
            String[] classArray = new String[classList.size()];
            for(int i=0; i < classList.size(); i++){
                classArray[i] = classList.get(i);
            }
            JComboBox box = new JComboBox(classArray);
            return box;
        }
        public JApplet createFooter(){
            JApplet footer = new JApplet();
            footer.getContentPane().setBackground(new Color(255,255,255));
            ImageIcon gradrlogo = new ImageIcon(new ImageIcon(System.getProperty("user.dir") +"/GUI/gradrlogo.png").getImage().getScaledInstance(200, 50, Image.SCALE_SMOOTH));
            JLabel logoLabel = new JLabel(gradrlogo);
            footer.add(logoLabel);
            return footer;
        }
}
