package GUI;
import Logic.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;
import java.awt.Color;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class assignmentsPage extends JPanel {
	public static teacher currentTeacher;
	String username = currentTeacher.username;
	public JComboBox classDropDown = new JComboBox( );
	String className;

	public JLabel title = new JLabel( );
	public Font titleFont = new Font("Stencil", Font.PLAIN, 40);
	public BorderLayout assignmentsPageLayout = new BorderLayout( );

	public static String classroom = new String( );
	public assignmentsPage( ) {
		String classroom = "Assignments Page";
		classDropDown = createDropDown( );
		JPanel topBar = new JPanel( );
		
		FlowLayout barLayout = new FlowLayout( );
		topBar.setLayout(barLayout);

		setLayout(assignmentsPageLayout);

		title.setText("Assignments Page");
		title.setFont(titleFont);
		title.setVisible(true);
		topBar.add(title);
	
		topBar.add(classDropDown);
		JButton update = new JButton("Update");
		topBar.add(update);
		add(topBar, assignmentsPageLayout.NORTH);

		JPanel gradesHomePage = createGradesHomePage( );
		add(gradesHomePage, assignmentsPageLayout.NORTH);
		gradesHomePage.add(update);

		update.addActionListener(new ActionListener( ) {
			public void actionPerformed(ActionEvent e) {
				update((String)classDropDown.getSelectedItem( ));
			}
		});

		classroom = (String)classDropDown.getSelectedItem( );

		System.out.println("CLASSROOM FROM DROPDOWN" + classroom);
		
		JPanel bottomBar = new JPanel();
        FlowLayout bottomBarLayout = new FlowLayout();
        bottomBar.setLayout(bottomBarLayout);
        JButton attendanceButton = new JButton("Attendance");
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
		JButton addAssignmentButton = new JButton("Add Assignment");
		JButton statsButton = new JButton("Statistics");

		bottomBar.add(addAssignmentButton);
		bottomBar.add(statsButton);
        bottomBar.add(attendanceButton);
        bottomBar.add(saveButton);
        bottomBar.add(cancelButton);

        add(bottomBar, assignmentsPageLayout.SOUTH);

		add (new DataFileTable2('g', classroom), assignmentsPageLayout.CENTER);

	}

	public void update(String classroom) {
		JPanel gradesHomePage = createGradesHomePage( );

		title.setText(classroom);
		if (className == "Assignments Page") {
			swapCenter(gradesHomePage);
			
		}
		else {
			swapCenter(new DataFileTable2('g', classroom));
		}
	}


	public void swapCenter(JPanel replacementPanel) {
		if (assignmentsPageLayout.getLayoutComponent(assignmentsPageLayout.CENTER) != null) {
			remove(assignmentsPageLayout.getLayoutComponent(assignmentsPageLayout.CENTER));
		}

		add(replacementPanel, assignmentsPageLayout.CENTER);
		validate( );
		repaint( );
	}

	public JComboBox createDropDown( ) {
		FileIO io = new FileIO( );
		List<String> classList = new ArrayList<String>( );
		classList = io.readClassList(username);
		String[ ] classArray = new String[classList.size( )];
		
		for (int i = 0; i < classList.size( ); i++)
			classArray[i] = classList.get(i);

		JComboBox box = new JComboBox(classArray);
		return box;
	}

	public JPanel createGradesHomePage( ) {
		JPanel gradePage = new JPanel( );
		JLabel gradeText = new JLabel( );
		Font textFont = new Font("Stencil", Font.PLAIN, 15);
		gradeText.setText("Please select a class from the dropdown menu.");
		classDropDown = createDropDown( );
		gradePage.add(classDropDown);

		gradeText.setFont(textFont);
		gradeText.setVisible(true);
		gradePage.add(gradeText);
		return gradePage;
	}
}
