import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
//package GradeBook;
//GradeBook Class
public class gradebook{
    //creates a list of classrooms
    public static List<classroom> classList = new ArrayList<classroom>();
    
    //main function
    public void run(){
        System.out.println("Welcome to the gradebook");
        int choice = 1;
        //Loops until the user inputs 0
        while (choice != 0){
            Scanner userInput = new Scanner (System.in);
            //Takes user input
            System.out.print("What would you like to do?\n");
            System.out.println("\t1)Add Class\n\t2)Display List of Classes\n\t3)Edit Class\n\t4)Delete Class\n\t0)Exit\n");
            choice = userInput.nextInt();
            switch(choice){
                case 1:
                    addClass();
                    break;
                case 2:
                    displayClasses();
                    break;
                case 3:
                    editClass();
                    break;
                case 4:
                    deleteClass();
                    break;
                case 0:
                    break;
            }
        }
    }
    //displays  a list of all the classes.
    public void displayClasses(){
        for (int i = 0; i < classList.size(); i++){
            System.out.println("Class " + i + ") " + classList.get(i).getName());
        }
    }

    //add a class
    public void addClass(){
        Scanner userInput = new Scanner (System.in);
        System.out.print("Whats the name of the class?");
        String n;
        n = userInput.next();
        classroom c = new classroom(n);
        classList.add(c);
    }
    
    //Delete class 
    public void deleteClass(){
        System.out.println("Which one?");
        displayClasses();
        int n; 
        Scanner userInput = new Scanner (System.in);
        n = userInput.nextInt();
        classList.remove(n);
    }
    //edit class.
    public void editClass(){
        System.out.println("Which one?");
        displayClasses();
        int n; 
        Scanner userInput = new Scanner (System.in);
        n = userInput.nextInt();
        classList.get(n).edit();
    }
}