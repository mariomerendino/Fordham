import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.*;
 
public class DataFileTable2 extends JPanel {
    public DataFileTable2(String dataFilePath) {
        JTable table;
        DataFileTableModel2 model;
        Font f;
         
        f = new Font("SanSerif",Font.PLAIN,24);
        setFont(f);
        setLayout(new BorderLayout());
         
        model = new DataFileTableModel2(dataFilePath);
         
        table = new JTable();
        table.setModel(model);
        table.createDefaultColumnsFromModel();
         
        JScrollPane scrollpane = new JScrollPane(table);
        add(scrollpane);
    }
     
    /*public Dimension getPreferredSize(){
        return new Dimension(400, 300);
    }*/
  
   
//    public static void main(String s[ ]) {


//       DataFileTable2 t = new DataFileTable2(System.getProperty("user.dir") + "/data/brooke/master_student_list.csv");

//	t.display( );
//    }

    public void display( ) {
//    public static void main(String args[ ]) {
        JFrame frame = new JFrame("Data File Table");
        DataFileTable2 panel;
         
        panel = new DataFileTable2(System.getProperty("user.dir") + "/data/brooke/master_student_list.csv");
         
//        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.setForeground(Color.black);
        frame.setBackground(Color.lightGray);
        frame.getContentPane().add(panel,"Center");
         
        frame.setSize(panel.getPreferredSize());
        frame.setVisible(true);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

   }
}
